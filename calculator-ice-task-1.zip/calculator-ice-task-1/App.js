import { useState } from 'react'; 
import {
  View, 
  Text, 
  TouchableOpacity, 
  StyleSheet
} from 'react-native'; 

function CalculatorApp() {
  const [input, setInput] = useState('');

  const handlePress = (value) => {
    if (value === '=') {
      try {
        setInput(eval(input).toString());
      } catch (error) {
        setInput('Error');
      }
    } else if (value === 'C') {
      setInput('');
    } else if (value === 'X^2') {
      try {
        setInput((Math.pow(parseFloat(input), 2)).toString());
      } catch (error) {
        setInput('Error');
      }
    } else {
      setInput(input + value);
    }
  };

  const Button = ({ onPress, title }) => (
    <TouchableOpacity style={styles.calculatorButtons} onPress={() => onPress(title)}>
      <Text style={styles.buttonTexts}>{title}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Calculator App</Text> 
      <Text style={styles.inputText}>{input}</Text>
      <View style={styles.buttonLayout}>
        <Button onPress={handlePress} title="1" />
        <Button onPress={handlePress} title="2" />
        <Button onPress={handlePress} title="3" />
        <Button onPress={handlePress} title="+" />
      </View>
      <View style={styles.buttonLayout}>
        <Button onPress={handlePress} title="4" />
        <Button onPress={handlePress} title="5" />
        <Button onPress={handlePress} title="6" />
        <Button onPress={handlePress} title="-" />
      </View>
      <View style={styles.buttonLayout}>
        <Button onPress={handlePress} title="7" />
        <Button onPress={handlePress} title="8" />
        <Button onPress={handlePress} title="9" />
        <Button onPress={handlePress} title="X^2" />
      </View>
      <View style={styles.buttonLayout}>
        <Button onPress={handlePress} title="0" />
        <Button onPress={handlePress} title="." />
        <Button onPress={handlePress} title="C" />
        <Button onPress={handlePress} title="/" />
      </View>
      <View style={styles.buttonLayout}>
        <Button onPress={handlePress} title="=" />
      </View>
    </View>
  ); 
}

const styles = StyleSheet.create({
  container: {
    flex: 1, 
    padding: 20,
    backgroundColor: '#2e8b57',  
  },
  heading: {
    fontSize: 30, 
    marginBottom: 10, 
    textAlign: 'center',
    fontWeight: 'bold',
    color: '#fff',  
  }, 
  buttonLayout: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  inputText: {
    fontSize: 24,
    marginBottom: 20,
    textAlign: 'center',
    width: '100%',
    padding: 20,
    backgroundColor: '#fff',  
    color: '#000',  
  },
  calculatorButtons: {
    width: 65,
    height: 80,
    justifyContent: 'center',
    alignItems: 'center',
    margin: 5,
    backgroundColor: '#fff',  
    borderRadius: 25,
  },
  buttonTexts: {
    fontSize: 34,
    color: '#333',
  },
});

export default CalculatorApp;
